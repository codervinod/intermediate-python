import unittest

class MyTest(unittest.TestCase):

    def test_pass(self):
        pass

if __name__ == '__main__':
    unittest.main()
