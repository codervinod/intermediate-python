import numpy as np

z = np.random.random((50, 50))
zmin, zmax = z.min(), z.max()
print 'Min: ', zmin
print 'Max: ', zmax
